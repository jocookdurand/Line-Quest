
import React, { useState, useEffect, useRef } from "react";

/*
  Line Quest - consolidated single-file app component.
  This contains:
    - Profile & class management (localStorage)
    - World selection, themed music (placeholder URLs)
    - Problem generator (table, points, graph, battle, boss)
    - Battle mode and boss fights
    - Per-class and Global leaderboards, Hall of Fame
    - Exports (CSV/JSON), Print, Reset (teacher password: "mischief managed")
    - Animations: sparkle, fireworks (simple canvas), entrance animations
    - Carousel for Global Hall of Fame
  Note: The code focuses on clarity and functionality rather than perfect UI polish.
*/

const WORLD_ICONS = { forest: '🌲', desert: '🌵', ice: '❄️', space: '🚀' };
const TEACHER_PASSWORD = 'mischief managed';

function nowDateStr() {
  const d = new Date();
  return d.toISOString().slice(0,10);
}

function readJSON(key, fallback) {
  try {
    const v = localStorage.getItem(key);
    return v ? JSON.parse(v) : fallback;
  } catch(e) {
    return fallback;
  }
}
function writeJSON(key, val) {
  localStorage.setItem(key, JSON.stringify(val));
}

function defaultStore() {
  return {
    classes: {},
    activeClass: null
  };
}

// helpers for fireworks (simple confetti)
function launchFireworks() {
  // use canvas-confetti style minimal implementation
  const canvas = document.getElementById('fireworks');
  if(!canvas) return;
  const ctx = canvas.getContext('2d');
  canvas.width = window.innerWidth;
  canvas.height = window.innerHeight;
  const particles = [];
  const colors = ['#ff5f6d','#ffc371','#ffd56b','#8ef5ff','#b59bff'];
  for(let i=0;i<80;i++){
    particles.push({
      x: Math.random()*canvas.width,
      y: Math.random()*canvas.height*0.6,
      vx:(Math.random()-0.5)*6,
      vy:(Math.random()-0.5)*6,
      r: Math.random()*3+1,
      c: colors[Math.floor(Math.random()*colors.length)],
      life: Math.random()*60+40
    });
  }
  let frame = 0;
  function step(){
    frame++;
    ctx.clearRect(0,0,canvas.width,canvas.height);
    particles.forEach(p=>{
      p.x += p.vx;
      p.y += p.vy + 0.5;
      p.vy *= 0.99;
      p.life -= 1;
      ctx.beginPath();
      ctx.fillStyle = p.c;
      ctx.arc(p.x,p.y,p.r,0,Math.PI*2);
      ctx.fill();
    });
    if(frame < 160) requestAnimationFrame(step);
    else ctx.clearRect(0,0,canvas.width,canvas.height);
  }
  step();
}

/* Simple CSV helpers */
function csvEscapeCell(c) {
  if (c == null) return '';
  const s = String(c);
  if (s.includes(',') || s.includes('"') || s.includes('\n')) {
    return `"${s.replace(/"/g,'""')}"`;
  }
  return s;
}
function downloadFile(filename, content, mime='text/plain') {
  const blob = new Blob([content], {type: mime});
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = filename;
  document.body.appendChild(a);
  a.click();
  a.remove();
  URL.revokeObjectURL(url);
}

/* MAIN APP */
export default function App(){
  // store
  const storeKey = 'linequest_store_v1';
  const [store, setStore] = useState(readJSON(storeKey, defaultStore()));
  const [mode, setMode] = useState('leaderboard'); // leaderboard | play
  const [activeClass, setActiveClass] = useState(store.activeClass || null);
  const [currentProfile, setCurrentProfile] = useState(null);
  const [selectedWorld, setSelectedWorld] = useState(null);
  const [muted, setMuted] = useState(false);

  // UI state
  const [showTeacherOptions, setShowTeacherOptions] = useState(false);
  const [showCreateClass, setShowCreateClass] = useState(false);
  const [showCreateProfile, setShowCreateProfile] = useState(false);
  const [newClassName, setNewClassName] = useState('');
  const [newProfileName, setNewProfileName] = useState('');
  const [activeTab, setActiveTab] = useState('global'); // global or class
  const [celebrationQueue, setCelebrationQueue] = useState([]); // for entrance animations

  // Problem / game state (kept minimal here; generated when play starts)
  const [currentProblem, setCurrentProblem] = useState(null);
  const [inputM, setInputM] = useState('');
  const [inputB, setInputB] = useState('');
  const [message, setMessage] = useState(null);
  const [scoreSession, setScoreSession] = useState(0);

  // sounds (placeholders)
  const soundUrls = {
    forest: 'https://www.soundhelix.com/examples/mp3/SoundHelix-Song-1.mp3',
    desert: 'https://www.soundhelix.com/examples/mp3/SoundHelix-Song-2.mp3',
    ice: 'https://www.soundhelix.com/examples/mp3/SoundHelix-Song-3.mp3',
    space: 'https://www.soundhelix.com/examples/mp3/SoundHelix-Song-4.mp3'
  };
  const sfx = {
    correct: new Audio('https://actions.google.com/sounds/v1/cartoon/clang_and_wobble.ogg'),
    wrong: new Audio('https://actions.google.com/sounds/v1/cartoon/cartoon_boing.ogg'),
    hit: new Audio('https://actions.google.com/sounds/v1/impacts/metal_clang.ogg'),
    applause: new Audio('https://actions.google.com/sounds/v1/human_voices/applause.ogg'),
  };

  useEffect(()=>{
    // persist store when changed
    writeJSON(storeKey, store);
    setActiveClass(store.activeClass || null);
  }, [store]);

  useEffect(()=>{
    // load active class on mount
    if(!activeClass && store && store.activeClass) setActiveClass(store.activeClass);
  },[]);

  // Helper: get class object, ensure structure
  function ensureClass(name) {
    const s = {...store};
    if(!s.classes[name]) {
      s.classes[name] = { profiles: {}, hallOfFame: { forest:[], desert:[], ice:[], space:[] }, celebrated: {}, createdAt: nowDateStr() };
    }
    return s;
  }

  // Create class
  function createClass(name) {
    if(!name) return alert('Enter a class name');
    const s = ensureClass(name);
    s.activeClass = name;
    setStore(s);
    setActiveClass(name);
    setShowCreateClass(false);
  }

  // Delete class (password protected)
  function deleteClass(name) {
    const pass = prompt('Enter teacher password to delete this class:');
    if(pass !== TEACHER_PASSWORD) return alert('Access denied');
    const s = {...store};
    delete s.classes[name];
    if(s.activeClass === name) s.activeClass = null;
    setStore(s);
    setActiveClass(s.activeClass || null);
  }

  // Profiles
  function createProfile(name) {
    if(!name) return alert('Enter a name');
    const s = {...store};
    s.classes = {...s.classes};
    s.classes[activeClass] = s.classes[activeClass] || { profiles: {}, hallOfFame: { forest:[], desert:[], ice:[], space:[] }, celebrated: {} };
    if(s.classes[activeClass].profiles[name]) return alert('Profile exists');
    s.classes[activeClass].profiles[name] = { name, muted: false, settings: { difficulty: 'normal', problemTypes: {table:true,points:true,graph:true,battle:true}, speedMode:false }, highScores: {forest:0,desert:0,ice:0,space:0}, totalScore:0, createdAt: nowDateStr() };
    setStore(s);
    setShowCreateProfile(false);
  }

  function deleteProfile(name) {
    const s = {...store};
    delete s.classes[activeClass].profiles[name];
    setStore(s);
    if(currentProfile && currentProfile.name === name) setCurrentProfile(null);
  }

  // Select profile to play
  function selectProfile(name) {
    setCurrentProfile( store.classes[activeClass].profiles[name] );
    setMode('play');
    setSelectedWorld(null);
    setCurrentProblem(null);
    setScoreSession(0);
  }

  // world start
  function startInWorld(worldId) {
    setSelectedWorld(worldId);
    setMode('play');
    // start with new problem
    nextProblem(null, 0, worldId);
    // start background music if not muted
    if(!muted) {
      try {
        const a = new Audio(soundUrls[worldId]);
        a.loop = true;
        a.volume = 0.4;
        a.play().catch(()=>{});
        // store ref to pause later
        window._lq_bg_audio = a;
      } catch(e){}
    }
  }

  // stop music
  function stopMusic() {
    try {
      if(window._lq_bg_audio) { window._lq_bg_audio.pause(); window._lq_bg_audio= null; }
    } catch(e){}
  }

  // Problem generation (uses settings/difficulty lightly)
  function nextProblem(prev, sessionScore=0, forcedWorld=null) {
    const types = ['table','points','graph','battle'];
    // consider settings
    let allowed = types.filter(t=> store.classes[activeClass].profiles[currentProfile.name].settings.problemTypes[t]);
    if(allowed.length===0) allowed = types;
    const t = allowed[Math.floor(Math.random()*allowed.length)];
    const world = forcedWorld || selectedWorld || Object.keys(WORLD_ICONS)[Math.floor(Math.random()*4)];
    if(t==='table') {
      const m = Math.floor(Math.random()*5)-2;
      const b = Math.floor(Math.random()*11)-5;
      const points = [];
      for(let x=-2;x<=2;x++) points.push({x,y:m*x+b});
      setCurrentProblem({type:'table', world, prompt:'Find equation from table', points});
    } else if(t==='points') {
      const x1 = Math.floor(Math.random()*7)-3;
      const x2 = x1 + (Math.floor(Math.random()*5)+1);
      const m = Math.floor(Math.random()*5)-2;
      const b = Math.floor(Math.random()*11)-5;
      const p1 = {x:x1, y:m*x1+b}, p2={x:x2,y:m*x2+b};
      setCurrentProblem({type:'points', world, prompt:'Find equation through two points', p1, p2});
    } else if(t==='graph') {
      const slope = Math.floor(Math.random()*5)-2;
      const intercept = Math.floor(Math.random()*11)-5;
      setCurrentProblem({type:'graph', world, prompt:'Find equation from graph', slope, intercept});
    } else {
      const slope = Math.floor(Math.random()*5)-2;
      const intercept = Math.floor(Math.random()*11)-5;
      const correct = {m:slope,b:intercept};
      const choices = [correct];
      while(choices.length<4){
        const m=Math.floor(Math.random()*5)-2;
        const b=Math.floor(Math.random()*11)-5;
        if(!choices.find(c=>c.m===m&&c.b===b)) choices.push({m,b});
      }
      choices.sort(()=>Math.random()-0.5);
      setCurrentProblem({type:'battle', world, prompt:'Battle Mode! Choose the correct equation', slope, intercept, choices, enemyHP:3, enemyId: Math.floor(Math.random()*5)});
    }
    setInputM(''); setInputB(''); setMessage(null);
  }

  // Compute truth
  function computeTruth(prob){
    if(!prob) return {m:0,b:0};
    if(prob.type==='table'){ const p1=prob.points[0]; const p2=prob.points.find(p=>p.x!==p1.x); const m=(p2.y-p1.y)/(p2.x-p1.x); const b=p1.y-m*p1.x; return {m,b}; }
    if(prob.type==='points'){ const p1=prob.p1; const p2=prob.p2; const m=(p2.y-p1.y)/(p2.x-p1.x); const b=p1.y-m*p1.x; return {m,b}; }
    if(prob.type==='graph' || prob.type==='battle') return {m:prob.slope, b:prob.intercept};
    return {m:0,b:0};
  }

  function parseMaybeFraction(s){
    if(!s) return NaN;
    if(s.includes('/')){ const [n,d]=s.split('/').map(x=>parseFloat(x.trim())); if(isNaN(n)||isNaN(d)||d===0) return NaN; return n/d; }
    return parseFloat(s);
  }

  // submit typed answer
  function submitAnswer(){
    const truth = computeTruth(currentProblem);
    const um = parseMaybeFraction(inputM.trim());
    const ub = parseMaybeFraction(inputB.trim());
    if(isNaN(um) || isNaN(ub)) { setMessage({type:'error', text:'Enter numbers (e.g. 2 or 3/2)'}); sfx.wrong.play().catch(()=>{}); return; }
    if(Math.abs(um-truth.m)<1e-6 && Math.abs(ub-truth.b)<1e-6){
      sfx.correct.play().catch(()=>{});
      setMessage({type:'success', text:`Correct! y = ${truth.m}x + ${truth.b}`});
      // award points
      const add = 5;
      setScoreSession(sc=>sc+add);
      // update profile high score for the world if better
      const s = {...store};
      const prof = s.classes[activeClass].profiles[currentProfile.name];
      if(!prof) return;
      prof.highScores[currentProblem.world] = Math.max(prof.highScores[currentProblem.world]||0, prof.highScores[currentProblem.world] + add);
      prof.totalScore = Object.values(prof.highScores).reduce((a,b)=>a+b,0);
      s.classes[activeClass].profiles[currentProfile.name] = prof;
      setStore(s);
      // check perfect threshold (we'll use 30 as max for simplicity)
      if(prof.highScores[currentProblem.world] >= 30){
        // add to class hof and global
        addToHallOfFame(activeClass, currentProfile.name, currentProblem.world);
      }
      // next problem
      setTimeout(()=> nextProblem(currentProblem, scoreSession+add), 700);
    } else {
      sfx.wrong.play().catch(()=>{});
      setMessage({type:'wrong', text:'Not quite. Try again or use a hint.'});
    }
  }

  // handle MC choice
  function handleChoice(choice){
    const truth = computeTruth(currentProblem);
    if(choice.m === truth.m && choice.b === truth.b){
      sfx.hit.play().catch(()=>{});
      setMessage({type:'success', text:'Hit!'});
      // decrease enemy HP
      const newHP = (currentProblem.enemyHP||3)-1;
      const prob = {...currentProblem, enemyHP:newHP};
      setCurrentProblem(prob);
      // award points
      setScoreSession(sc=>sc+2);
      if(newHP<=0){
        // defeated
        sfx.applause.play().catch(()=>{});
        const add = 8;
        setScoreSession(sc=>sc+add);
        // update profile
        const s = {...store};
        const prof = s.classes[activeClass].profiles[currentProfile.name];
        prof.highScores[currentProblem.world] = Math.max(prof.highScores[currentProblem.world]||0, prof.highScores[currentProblem.world] + add);
        prof.totalScore = Object.values(prof.highScores).reduce((a,b)=>a+b,0);
        s.classes[activeClass].profiles[currentProfile.name] = prof;
        setStore(s);
        if(prof.highScores[currentProblem.world]>=30) addToHallOfFame(activeClass, currentProfile.name, currentProblem.world);
        setTimeout(()=> nextProblem(currentProblem, scoreSession+add), 900);
      }
    } else {
      sfx.wrong.play().catch(()=>{});
      setMessage({type:'wrong', text:'Missed!'});
    }
  }

  // Hints
  function getHint(prob){
    if(!prob) return '';
    if(prob.type==='table'){ const p1=prob.points[0]; const p2=prob.points.find(p=>p.x!==p1.x); return `Use points (${p1.x},${p1.y}) & (${p2.x},${p2.y}). Slope = (y2-y1)/(x2-x1).`; }
    if(prob.type==='points'){ return `Slope = (${prob.p2.y} - ${prob.p1.y}) / (${prob.p2.x} - ${prob.p1.x}). Then solve for b.`; }
    if(prob.type==='graph'){ return 'Look at rise/run and where the line crosses y-axis at x=0.'; }
    if(prob.type==='battle'){ return `Pick the choice that matches slope ${prob.slope} and intercept ${prob.intercept}.`; }
    return '';
  }

  // Hall of Fame handling
  function ensureHallStruct(cls) {
    const s = {...store};
    s.classes[cls] = s.classes[cls] || { profiles: {}, hallOfFame: { forest:[], desert:[], ice:[], space:[] }, celebrated:{} };
    s.classes[cls].hallOfFame = s.classes[cls].hallOfFame || { forest:[], desert:[], ice:[], space:[] };
    s.classes[cls].celebrated = s.classes[cls].celebrated || {};
    return s;
  }

  function addToHallOfFame(cls, player, world){
    const s = ensureHallStruct(cls);
    if(!s.classes[cls].hallOfFame[world].includes(player)){
      s.classes[cls].hallOfFame[world].push(player);
      // add global as well: we'll store global in root of store under globalHall
      s.globalHall = s.globalHall || [];
      if(!s.globalHall.includes(player)) s.globalHall.push(player);
      // celebrated flags prevent repeat animations
      s.classes[cls].celebrated = s.classes[cls].celebrated || {};
      s.classes[cls].celebrated[player] = s.classes[cls].celebrated[player] || {};
      const already = s.classes[cls].celebrated[player][world];
      s.classes[cls].celebrated[player][world] = true;
      setStore(s);
      // queue celebration (class)
      setCelebrationQueue(q=>[...q, {type:'class', cls, player, world}]);
      // queue global celebration if newly added globally
      if(!s.globalCelebrated) s.globalCelebrated = {};
      if(!s.globalCelebrated[player]){
        s.globalCelebrated[player] = true;
        setCelebrationQueue(q=>[...q, {type:'global', player, world}]);
      }
    }
  }

  // Export CSV/JSON
  function exportJSON(global=false) {
    const now = nowDateStr();
    const data = global ? buildGlobalExport() : buildClassExport(activeClass);
    const filename = `leaderboard_${global ? 'global' : (activeClass||'class')}_${now}.json`.replace(/\s+/g,'_');
    downloadFile(filename, JSON.stringify(data, null, 2), 'application/json');
  }
  function exportCSV(global=false) {
    const now = nowDateStr();
    const exportData = global ? buildGlobalExport() : buildClassExport(activeClass);
    // build CSV: players table then Hall of Fame section
    let rows = [];
    // top header
    const players = exportData.profiles || {};
    const header = ['Player','Class','Forest','Desert','Ice','Space','Total','Difficulty'];
    rows.push(header.join(','));
    for(const name of Object.keys(players)){
      const p = players[name];
      const row = [ csvEscapeCell(p.name), csvEscapeCell(p.class||''), p.highScores.forest||0, p.highScores.desert||0, p.highScores.ice||0, p.highScores.space||0, p.totalScore||0, p.settings?.difficulty || '' ];
      rows.push(row.map(csvEscapeCell).join(','));
    }
    // Hall of Fame header
    rows.push('');
    rows.push('Hall of Fame');
    rows.push('World,Champions');
    const hof = exportData.hallOfFame || {};
    for(const w of ['forest','desert','ice','space']){
      const champions = (hof[w] || []).join('; ');
      rows.push(`${w},${csvEscapeCell(champions)}`);
    }
    const filename = `leaderboard_${global ? 'global' : (activeClass||'class')}_${now}.csv`.replace(/\s+/g,'_');
    downloadFile(filename, rows.join('\n'), 'text/csv');
  }

  function buildClassExport(cls){
    const s = store.classes[cls] || { profiles:{}, hallOfFame:{forest:[],desert:[],ice:[],space:[]}};
    const out = { profiles: {}, hallOfFame: s.hallOfFame || {} };
    for(const name of Object.keys(s.profiles||{})){
      const p = s.profiles[name];
      out.profiles[name] = { name: p.name, highScores: p.highScores, totalScore: p.totalScore, settings: p.settings, class: cls };
    }
    return out;
  }
  function buildGlobalExport(){
    const out = { profiles: {}, hallOfFame: {} };
    // combine all classes, choose best per player (and record class)
    for(const cls of Object.keys(store.classes||{})){
      const c = store.classes[cls];
      for(const name of Object.keys(c.profiles||{})){
        const p = c.profiles[name];
        if(!out.profiles[name] || (p.totalScore > out.profiles[name].totalScore)){
          out.profiles[name] = { name: p.name, highScores: p.highScores, totalScore: p.totalScore, settings: p.settings, class: cls };
        }
      }
      // merge hall of fame
      for(const w of ['forest','desert','ice','space']){
        out.hallOfFame[w] = out.hallOfFame[w] || [];
        out.hallOfFame[w] = Array.from(new Set([...out.hallOfFame[w], ...(c.hallOfFame?.[w]||[])]));
      }
    }
    // global hall of fame list
    out.globalHall = Array.from(new Set([].concat(...Object.values(out.hallOfFame||{}))));
    return out;
  }

  // Reset (teacher password)
  function resetActiveClass() {
    const pass = prompt('Enter teacher password to reset leaderboards for this class:');
    if(pass !== TEACHER_PASSWORD) return alert('Access denied');
    const s = {...store};
    if(activeClass && s.classes[activeClass]) {
      s.classes[activeClass].profiles = {};
      s.classes[activeClass].hallOfFame = { forest:[], desert:[], ice:[], space:[] };
      s.classes[activeClass].celebrated = {};
      setStore(s);
      alert('Leaderboard and Hall of Fame have been reset for this class.');
    } else {
      alert('No active class to reset.');
    }
  }

  // Print (uses window.print)
  function printLeaderboard(global=false) {
    // prepare a print-friendly new window content, but we use default print dialog in-place
    window.print();
  }

  // Hall of Fame popup data
  const [hofPopup, setHofPopup] = useState(null);

  // Carousel auto-scroll
  const carouselRef = useRef(null);
  useEffect(()=>{
    let t;
    function tick(){
      const el = carouselRef.current;
      if(!el) return;
      el.scrollBy({ left: 220, behavior: 'smooth' });
      t = setTimeout(tick, 4500);
    }
    t = setTimeout(tick, 3000);
    return ()=>clearTimeout(t);
  },[store.globalHall]);

  // helper renderers for leaderboards
  function renderClassLeaderboard(cls){
    const c = store.classes[cls] || { profiles:{}, hallOfFame:{forest:[],desert:[],ice:[],space:[]}};
    // build per-world top10
    const rows = Object.values(c.profiles || {}).sort((a,b)=> (b.highScores?.forest||0) - (a.highScores?.forest||0)).slice(0,10);
    return (
      <div>
        <h3>Class: {cls}</h3>
        {['forest','desert','ice','space'].map(world=>(
          <div key={world} className="card" style={{marginBottom:12}}>
            <h4>{WORLD_ICONS[world]} {world.charAt(0).toUpperCase()+world.slice(1)} World</h4>
            <table><thead><tr><th>#</th><th>Player</th><th>Difficulty</th><th>Score</th></tr></thead>
              <tbody>
                {Object.values(c.profiles||{}).sort((a,b)=> (b.highScores?.[world]||0)-(a.highScores?.[world]||0)).slice(0,10).map((p,idx)=>(
                  <tr key={p.name}>
                    <td>{idx+1}</td>
                    <td className={ (c.hallOfFame?.[world]||[]).includes(p.name) ? 'sparkle':'' }>{ (c.hallOfFame?.[world]||[]).includes(p.name) ? '✨ '+p.name : p.name }</td>
                    <td>{p.settings?.difficulty}</td>
                    <td>{p.highScores?.[world]||0}</td>
                  </tr>
                ))}
              </tbody>
            </table>
            <div style={{marginTop:8}}>
              <strong>🎖️ Hall of Fame</strong>
              <div className="hof-glow" style={{marginTop:6, padding:8, display:'flex', gap:8, flexWrap:'wrap'}}>
                {(c.hallOfFame?.[world]||[]).length === 0 ? <span>No champions yet. Be the first!</span> :
                  (c.hallOfFame[world]||[]).map(name=>(
                    <button key={name} onClick={()=>setHofPopup({class:cls, player:name})} className="badge" style={{animation:'none'}}>
                      <span className="crown">👑</span><span className="sparkle">{name}</span>
                    </button>
                  ))
                }
              </div>
            </div>
          </div>
        ))}
        <div className="card">
          <h4>🏆 Total Scores</h4>
          <table><thead><tr><th>#</th><th>Player</th><th>Difficulty</th><th>Total</th></tr></thead>
            <tbody>
              {Object.values(c.profiles||{}).sort((a,b)=> (b.totalScore||0)-(a.totalScore||0)).slice(0,10).map((p,idx)=>(
                <tr key={p.name}><td>{idx+1}</td><td className={(Object.values(c.hallOfFame||{}).flat().includes(p.name))?'sparkle':''}>{p.name}</td><td>{p.settings?.difficulty}</td><td>{p.totalScore||0}</td></tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    )
  }

  function renderGlobalLeaderboard(){
    // gather best per player across classes
    const combined = {};
    for(const cls of Object.keys(store.classes||{})){
      const c = store.classes[cls];
      for(const pname of Object.keys(c.profiles||{})){
        const p = c.profiles[pname];
        if(!combined[pname] || (p.totalScore > combined[pname].totalScore)){
          combined[pname] = {...p, class: cls};
        }
      }
    }
    // per world top10 and total
    return (
      <div>
        <h3>Global Leaderboard</h3>
        {['forest','desert','ice','space'].map(world=>{
          const list = Object.values(combined).sort((a,b)=>(b.highScores?.[world]||0)-(a.highScores?.[world]||0)).slice(0,10);
          return (
            <div key={world} className="card" style={{marginBottom:12}}>
              <h4>{WORLD_ICONS[world]} {world.charAt(0).toUpperCase()+world.slice(1)} World</h4>
              <table><thead><tr><th>#</th><th>Player</th><th>Class</th><th>Difficulty</th><th>Score</th></tr></thead>
                <tbody>
                  {list.map((p,idx)=>(
                    <tr key={p.name}><td>{idx+1}</td><td className={(store.globalHall||[]).includes(p.name)?'sparkle':''}>{p.name}</td><td>{p.class}</td><td>{p.settings?.difficulty}</td><td>{p.highScores?.[world]||0}</td></tr>
                  ))}
                </tbody>
              </table>
            </div>
          )
        })}
        <div className="card">
          <h4>🏆 Total Scores (Global)</h4>
          <table><thead><tr><th>#</th><th>Player</th><th>Class</th><th>Difficulty</th><th>Total</th></tr></thead>
            <tbody>
              {Object.values(combined).sort((a,b)=>(b.totalScore||0)-(a.totalScore||0)).slice(0,10).map((p,idx)=>(
                <tr key={p.name}><td>{idx+1}</td><td className={(store.globalHall||[]).includes(p.name)?'sparkle':''}>{p.name}</td><td>{p.class}</td><td>{p.settings?.difficulty}</td><td>{p.totalScore||0}</td></tr>
              ))}
            </tbody>
          </table>
        </div>
        <div className="card hof-glow" style={{marginTop:12}}>
          <h4>🎖️ Global Hall of Fame</h4>
          <div style={{display:'flex', gap:8, flexWrap:'wrap', marginTop:8}}>
            {(store.globalHall||[]).length===0 ? <div>No global champions yet.</div> :
              (store.globalHall||[]).map(name=>(
                <button key={name} onClick={()=>setHofPopup({class:'global', player:name})} className="badge"><span className="crown">👑</span><span className="sparkle">{name}</span></button>
              ))
            }
          </div>
        </div>
      </div>
    )
  }

  // Celebration effect processing
  useEffect(()=>{
    if(celebrationQueue.length>0){
      const c = celebrationQueue[0];
      // run visual animation
      launchFireworks();
      // small visual entry: no sound (user requested visual only)
      setTimeout(()=>{
        // done, remove first
        setCelebrationQueue(q=>q.slice(1));
      }, 2200);
    }
  },[celebrationQueue]);

  // Hall of Fame popup content
  function HofPopup({info, onClose}){
    if(!info) return null;
    // collect profile info from classes/global
    const cls = info.class;
    let prof = null;
    if(cls === 'global') {
      // find in any class
      for(const c of Object.keys(store.classes||{})){
        if(store.classes[c].profiles && store.classes[c].profiles[info.player]) { prof = store.classes[c].profiles[info.player]; prof.class = c; break; }
      }
    } else {
      prof = store.classes[cls]?.profiles?.[info.player];
      if(prof) prof.class = cls;
    }
    if(!prof) {
      // try global map
      prof = { name: info.player, highScores:{}, totalScore:0, settings:{difficulty:'unknown'}, class:'unknown' };
    }
    // compute list of perfect worlds
    const perfects = Object.keys(prof.highScores||{}).filter(w=> (prof.highScores[w]||0) >= 30);
    return (
      <div style={{position:'fixed', left:0,top:0,width:'100%',height:'100%', display:'flex',alignItems:'center',justifyContent:'center', background:'rgba(0,0,0,0.4)'}}>
        <div style={{background:'white', padding:18, borderRadius:10, minWidth:320}}>
          <div style={{display:'flex', alignItems:'center', gap:10}}>
            <div style={{fontSize:28}}>👑</div>
            <div style={{fontSize:18, fontWeight:700}}>{prof.name}</div>
            <div style={{marginLeft:'auto', cursor:'pointer'}} onClick={onClose}>✖</div>
          </div>
          <div style={{marginTop:12}}>
            <div style={{fontWeight:600}}>Perfect Scores:</div>
            <div style={{fontSize:22, marginTop:8}}>{perfects.map(w=>WORLD_ICONS[w]).join(' ') || '—'}</div>
            <div style={{marginTop:12}}>Total Score: <strong>{prof.totalScore||0}</strong></div>
            <div>Difficulty: <strong>{prof.settings?.difficulty||'—'}</strong></div>
          </div>
        </div>
      </div>
    )
  }

  // Teacher Options panel (includes reset, export CSV/JSON, print, class management)
  function TeacherOptions(){
    const [showExportModal, setShowExportModal] = useState(false);
    const [showDeleteClassConfirm, setShowDeleteClassConfirm] = useState(false);
    const [exportType, setExportType] = useState('csv');
    const [exportScope, setExportScope] = useState('class');

    function handleExport(){
      if(exportType==='csv') exportCSV(exportScope==='global');
      else exportJSON(exportScope==='global');
      setShowExportModal(false);
    }

    return (
      <div style={{position:'absolute', right:24, top:72, background:'white', padding:12, borderRadius:8, boxShadow:'0 4px 12px rgba(0,0,0,0.08)'}}>
        <div style={{marginBottom:8}}><strong>Teacher Options</strong></div>
        <div style={{display:'flex', flexDirection:'column', gap:8}}>
          <button className="muted-btn" onClick={()=>{ const p = prompt('Enter teacher password to reset this class:'); if(p===TEACHER_PASSWORD){ resetActiveClass(); } else alert('Access denied');}}>🔒 Reset Leaderboard</button>
          <button className="muted-btn" onClick={()=>{ setExportType('csv'); setExportScope('class'); exportCSV(false); }}>⬇️ Export CSV (Class)</button>
          <button className="muted-btn" onClick={()=>{ setExportType('json'); setExportScope('class'); exportJSON(false); }}>⬇️ Export JSON (Class)</button>
          <button className="muted-btn" onClick={()=>{ setExportType('csv'); setExportScope('global'); exportCSV(true); }}>⬇️ Export CSV (Global)</button>
          <button className="muted-btn" onClick={()=>{ setExportType('json'); setExportScope('global'); exportJSON(true); }}>⬇️ Export JSON (Global)</button>
          <button className="muted-btn" onClick={()=>printLeaderboard(false)}>🖨️ Print Leaderboard</button>
          <div style={{borderTop:'1px solid #eee', paddingTop:8, marginTop:8}}>
            <div style={{fontWeight:600}}>Class Management</div>
            <div style={{marginTop:6}}>
              <input placeholder="New class name" value={newClassName} onChange={e=>setNewClassName(e.target.value)} style={{padding:6, width:180}} />
              <button className="btn" style={{marginLeft:8}} onClick={()=>{ if(newClassName){ createClass(newClassName); setNewClassName(''); }}}>Add Class</button>
            </div>
            <div style={{marginTop:8}}>
              <div style={{fontSize:13}}>Active class:</div>
              <select value={activeClass||''} onChange={e=>{ const s={...store}; s.activeClass=e.target.value; setStore(s); setActiveClass(e.target.value); }}>
                <option value=''>-- select --</option>
                {Object.keys(store.classes||{}).map(c=> <option key={c} value={c}>{c}</option>)}
              </select>
              <button className="muted-btn" style={{marginLeft:8}} onClick={()=>{ if(activeClass) deleteClass(activeClass); }}>Delete Class</button>
            </div>
          </div>
          <button className="muted-btn" onClick={()=>setShowTeacherOptions(false)}>Close</button>
        </div>
      </div>
    )
  }

  // Main UI render
  return (
    <div className="container">
      <div style={{display:'flex', alignItems:'center', justifyContent:'space-between', marginBottom:12}}>
        <div style={{display:'flex', gap:12, alignItems:'center'}}>
          <div style={{fontSize:20, fontWeight:700}}>Line Quest</div>
          <div style={{fontSize:13, color:'#6b7280'}}>{activeClass ? `Class: ${activeClass}` : 'No class selected'}</div>
        </div>
        <div style={{display:'flex', gap:8, alignItems:'center'}}>
          <div style={{fontSize:14}}>{currentProfile ? `${currentProfile.name}` : ''}</div>
          <button className="muted-btn" onClick={()=>{ setMuted(m=>!m); try{ if(window._lq_bg_audio) window._lq_bg_audio.muted = !muted; }catch(e){} }}>{muted ? '🔇' : '🔊'}</button>
          <button className="muted-btn" onClick={()=>setShowTeacherOptions(s=>!s)}>Teacher Options ⚙️</button>
        </div>
      </div>

      {showTeacherOptions && <TeacherOptions />}

      {/* Main menu / Leaderboards / Carousel */}
      {mode==='leaderboard' && (
        <>
          <div style={{display:'flex', gap:12, alignItems:'flex-start'}}>
            <div style={{flex:1}}>
              <div className="card">
                <h3>Global Hall of Fame Showcase</h3>
                <div ref={carouselRef} className="carousel" style={{overflowX:'auto', paddingTop:8}}>
                  {(store.globalHall||[]).length===0 ? <div>No champions yet</div> :
                    (store.globalHall||[]).map(name=>{
                      // find player's perfect worlds
                      let icons=[];
                      for(const cls of Object.keys(store.classes||{})){
                        const p = store.classes[cls].profiles && store.classes[cls].profiles[name];
                        if(p){
                          for(const w of Object.keys(p.highScores||{})){
                            if(p.highScores[w] >= 30) icons.push(WORLD_ICONS[w]);
                          }
                        }
                      }
                      icons = Array.from(new Set(icons));
                      return (
                        <button key={name} onClick={()=>setHofPopup({class:'global', player:name})} className="badge">
                          <span className="crown">👑</span><span className="sparkle">{name}</span>
                          <span style={{marginLeft:8}}>{icons.join(' ')}</span>
                        </button>
                      )
                    })
                  }
                </div>
              </div>

              <div style={{height:12}} />

              <div style={{display:'flex', gap:12}}>
                <button className="btn" onClick={()=>{ setMode('play'); setShowCreateProfile(true); }}>Play (Create/Select Profile)</button>
                <button className="muted-btn" onClick={()=>{ setActiveTab('global'); }}>View Global Leaderboard</button>
                <button className="muted-btn" onClick={()=>{ setActiveTab('class'); }}>View Class Leaderboard</button>
              </div>

              <div style={{height:12}} />

              <div>
                {activeTab==='global' ? renderGlobalLeaderboard() : (activeClass ? renderClassLeaderboard(activeClass) : <div className="card">Select a class to view its leaderboard.</div>)}
              </div>
            </div>

            <div style={{width:320}}>
              <div className="card">
                <h4>Classes</h4>
                <div style={{display:'flex', gap:8, flexDirection:'column'}}>
                  {Object.keys(store.classes||{}).length===0 ? <div>No classes yet. Add one in Teacher Options.</div> :
                    Object.keys(store.classes||{}).map(c=>(
                      <div key={c} style={{display:'flex', justifyContent:'space-between', alignItems:'center'}}>
                        <div>{c}</div>
                        <div style={{display:'flex', gap:8}}>
                          <button className="muted-btn" onClick={()=>{ const s={...store}; s.activeClass=c; setStore(s); setActiveClass(c); }}>Set Active</button>
                          <button className="muted-btn" onClick={()=>{ setShowCreateProfile(true); setNewProfileName(''); setActiveClass(c); }}>Profiles</button>
                        </div>
                      </div>
                    ))
                  }
                </div>
              </div>

              <div style={{height:12}} />

              <div className="card">
                <h4>Quick Start</h4>
                <ol style={{paddingLeft:18}}>
                  <li>Create/Select a class (Teacher Options)</li>
                  <li>Create a student profile</li>
                  <li>Select profile → Pick a world → Play</li>
                </ol>
              </div>
            </div>
          </div>
        </>
      )}

      {/* Play mode: profile selection or gameplay */}
      {mode==='play' && (
        <div className="grid grid-2" style={{marginTop:12}}>
          <div>
            {!currentProfile && (
              <div className="card">
                <h3>Select Profile (Class: {activeClass})</h3>
                <div style={{display:'flex', gap:8, flexDirection:'column', marginTop:8}}>
                  {Object.keys(store.classes[activeClass]?.profiles||{}).map(name=>(
                    <div key={name} style={{display:'flex', justifyContent:'space-between', alignItems:'center'}}>
                      <div>{name}</div>
                      <div style={{display:'flex', gap:8}}>
                        <button className="btn" onClick={()=>selectProfile(name)}>Play</button>
                        <button className="muted-btn" onClick={()=>deleteProfile(name)}>Delete</button>
                      </div>
                    </div>
                  ))}
                  <div style={{marginTop:8}}>
                    <input placeholder="New student name" value={newProfileName} onChange={e=>setNewProfileName(e.target.value)} />
                    <button className="btn" style={{marginLeft:8}} onClick={()=>{ createProfile(newProfileName); setNewProfileName(''); }}>Create</button>
                  </div>
                </div>
              </div>
            )}

            {currentProfile && !selectedWorld && (
              <div className="card">
                <h3>Welcome, {currentProfile.name}</h3>
                <p>Choose a world to start:</p>
                <div style={{display:'flex', gap:8}}>
                  {Object.keys(WORLD_ICONS).map(w=>(
                    <button key={w} className="muted-btn" onClick={()=>startInWorld(w)}>{WORLD_ICONS[w]} {w}</button>
                  ))}
                </div>
                <div style={{marginTop:8}}>
                  <button className="muted-btn" onClick={()=>{ setMode('leaderboard'); setCurrentProfile(null); stopMusic(); }}>Back to menu</button>
                </div>
              </div>
            )}

            {currentProfile && selectedWorld && currentProblem && (
              <div className="card">
                <div style={{display:'flex', justifyContent:'space-between', alignItems:'center'}}>
                  <h3>{selectedWorld} — {currentProblem.prompt}</h3>
                  <div>Score: {store.classes[activeClass].profiles[currentProfile.name].totalScore || 0}</div>
                </div>

                {currentProblem.type!=='battle' && (
                  <div style={{display:'flex', gap:12, marginTop:8}}>
                    <div style={{flex:1}}>
                      {currentProblem.type==='table' && (
                        <div>
                          <div>Table of values:</div>
                          <table><thead><tr><th>x</th><th>y</th></tr></thead><tbody>
                            {currentProblem.points.map((p,i)=>(<tr key={i}><td>{p.x}</td><td>{p.y}</td></tr>))}
                          </tbody></table>
                        </div>
                      )}
                      {currentProblem.type==='points' && (
                        <div>
                          <div>P1: ({currentProblem.p1.x},{currentProblem.p1.y})</div>
                          <div>P2: ({currentProblem.p2.x},{currentProblem.p2.y})</div>
                        </div>
                      )}
                      {currentProblem.type==='graph' && (
                        <div>
                          <div>Graph shown (visual). Slope: {currentProblem.slope}, Intercept: {currentProblem.intercept}</div>
                        </div>
                      )}
                    </div>

                    <div style={{width:260}}>
                      <div style={{fontWeight:600}}>Your Answer</div>
                      <div style={{display:'flex', gap:6, alignItems:'center', marginTop:6}}>
                        <div>y =</div>
                        <input type="text" placeholder="m" value={inputM} onChange={e=>setInputM(e.target.value)} style={{width:60}} />
                        <div>x +</div>
                        <input type="text" placeholder="b" value={inputB} onChange={e=>setInputB(e.target.value)} style={{width:80}} />
                      </div>
                      <div style={{marginTop:8, display:'flex', gap:8}}>
                        <button className="btn" onClick={submitAnswer}>Check</button>
                        <button className="muted-btn" onClick={()=>{ setInputM(''); setInputB(''); setMessage(null); }}>Clear</button>
                        <button className="muted-btn" onClick={()=>setMessage({type:'hint', text:getHint(currentProblem)})}>Hint</button>
                      </div>
                      {message && <div style={{marginTop:8, color: message.type==='error' ? 'red' : (message.type==='success' ? 'green' : 'orange')}}>{message.text}</div>}
                    </div>
                  </div>
                )}

                {currentProblem.type==='battle' && (
                  <div style={{display:'flex', gap:12, marginTop:8}}>
                    <div style={{flex:1}}>
                      <div style={{display:'flex', gap:12}}>
                        <div style={{minWidth:160}}>
                          <div style={{fontWeight:600}}>Enemy</div>
                          <div style={{fontSize:48}}>{selectedWorld==='space' ? '👾' : '👾'}</div>
                          <div>HP: {currentProblem.enemyHP}</div>
                        </div>
                        <div style={{flex:1}}>
                          <div style={{fontWeight:600}}>Choose the correct equation:</div>
                          <div style={{display:'flex', flexDirection:'column', gap:8, marginTop:8}}>
                            {currentProblem.choices.map((c,idx)=>(
                              <button key={idx} className="muted-btn" onClick={()=>handleChoice(c)}>{`y = ${c.m}x + ${c.b}`}</button>
                            ))}
                          </div>
                        </div>
                      </div>
                    </div>
                    <div style={{width:260}}>
                      <div style={{fontWeight:600}}>Info</div>
                      <div style={{marginTop:8}}>Tip: pick the line with slope & intercept that matches the enemy.</div>
                      <div style={{marginTop:12}}>
                        <button className="muted-btn" onClick={()=>setSelectedWorld(null)}>Leave World</button>
                      </div>
                    </div>
                  </div>
                )}

              </div>
            )}
          </div>

          <div>
            <div className="card">
              <h4>Progress Map</h4>
              <div style={{display:'flex', gap:8, alignItems:'center', justifyContent:'space-between'}}>
                {[0,5,10,15,20,25,30].map(m=>(
                  <div key={m} style={{textAlign:'center'}}><div style={{width:36,height:36, borderRadius:18, background: (store.classes[activeClass]?.profiles?.[currentProfile?.name]?.totalScore||0) >= m ? '#4f46e5' : '#e5e7eb', color: (store.classes[activeClass]?.profiles?.[currentProfile?.name]?.totalScore||0) >= m ? 'white' : '#6b7280', display:'flex', alignItems:'center', justifyContent:'center'}}>{m}</div></div>
                ))}
              </div>
            </div>

            <div style={{height:12}} />
            <div className="card">
              <h4>Profile</h4>
              {currentProfile ? (
                <div>
                  <div style={{fontWeight:700}}>{currentProfile.name} { Object.values(store.classes[activeClass]?.hallOfFame||{}).flat().includes(currentProfile.name) ? <span className="sparkle">🌟 Hall of Famer!</span> : null }</div>
                  <div style={{marginTop:8}}>Perfect Worlds: { Object.keys(currentProfile.highScores||{}).filter(w=>currentProfile.highScores[w]>=30).map(w=>WORLD_ICONS[w]).join(' ') || '—' }</div>
                  <div style={{marginTop:8}}>Difficulty: {currentProfile.settings?.difficulty}</div>
                  <div style={{marginTop:8}}>
                    <button className="muted-btn" onClick={()=>{ setSelectedWorld(null); setMode('leaderboard'); stopMusic(); }}>Back to Menu</button>
                  </div>
                </div>
              ) : <div>No profile selected</div>}
            </div>
          </div>
        </div>
      )}

      {/* create/select profile modal if showCreateProfile */}
      {showCreateProfile && (
        <div style={{position:'fixed', left:0, top:0, width:'100%', height:'100%', display:'flex', alignItems:'center', justifyContent:'center', background:'rgba(0,0,0,0.3)'}}>
          <div style={{background:'white', padding:16, borderRadius:8, width:480}}>
            <h3>Create or Select Profile (Class: {activeClass})</h3>
            <div style={{display:'flex', gap:8, marginTop:8}}>
              <input placeholder="New student name" value={newProfileName} onChange={e=>setNewProfileName(e.target.value)} />
              <button className="btn" onClick={()=>{ createProfile(newProfileName); setNewProfileName(''); }}>Create</button>
              <button className="muted-btn" onClick={()=>setShowCreateProfile(false)}>Close</button>
            </div>
            <div style={{marginTop:12}}>
              <h4>Existing profiles</h4>
              <div style={{display:'flex', flexDirection:'column', gap:6}}>
                {Object.keys(store.classes[activeClass]?.profiles||{}).length===0 ? <div>No profiles</div> :
                  Object.keys(store.classes[activeClass].profiles).map(n=>(
                    <div key={n} style={{display:'flex', justifyContent:'space-between', alignItems:'center'}}>
                      <div>{n}</div>
                      <div style={{display:'flex', gap:8}}>
                        <button className="btn" onClick={()=>selectProfile(n)}>Play</button>
                        <button className="muted-btn" onClick={()=>deleteProfile(n)}>Delete</button>
                      </div>
                    </div>
                  ))
                }
              </div>
            </div>
          </div>
        </div>
      )}

      {hofPopup && <HofPopup info={hofPopup} onClose={()=>setHofPopup(null)} />}

    </div>
  )
}
